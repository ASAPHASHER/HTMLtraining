import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { OnInit, OnDestroy, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements OnInit, OnDestroy {
  protected readonly title = signal('blockgame');

  // 20 rows x 10 columns grid for the block game
  board: number[][] = Array.from({ length: 20 }, () => Array(10).fill(0)); // static board (landed blocks)

  // Tetromino shapes (Tetris blocks)
  tetrominoes = [
    // I
    [
      [1, 1, 1, 1]
    ],
    // O
    [
      [1, 1],
      [1, 1]
    ],
    // T
    [
      [0, 1, 0],
      [1, 1, 1]
    ],
    // S
    [
      [0, 1, 1],
      [1, 1, 0]
    ],
    // Z
    [
      [1, 1, 0],
      [0, 1, 1]
    ],
    // J
    [
      [1, 0, 0],
      [1, 1, 1]
    ],
    // L
    [
      [0, 0, 1],
      [1, 1, 1]
    ]
  ];

  currentTetromino: number[][] = [];
  currentRow = 0;
  currentCol = 3; // Start near the center
  intervalId: any;
  gameOver = false;
  score = 0;
  colorMap = [
    '', // 0: empty
    'block-i', // 1: I
    'block-o', // 2: O
    'block-t', // 3: T
    'block-s', // 4: S
    'block-z', // 5: Z
    'block-j', // 6: J
    'block-l', // 7: L
    'block-active' // 8: active
  ];
  currentTetrominoIndex = 0;
  nextTetromino: number[][] = [];
  nextTetrominoIndex = 0;
  fallInterval = 500;

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  ngOnInit() {
    this.prepareNextTetromino();
    this.spawnTetromino();
    this.setFallInterval();
    if (isPlatformBrowser(this.platformId)) {
      window.addEventListener('keydown', this.handleKey);
    }
  }

  ngOnDestroy() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
    if (isPlatformBrowser(this.platformId)) {
      window.removeEventListener('keydown', this.handleKey);
    }
  }

  handleKey = (event: KeyboardEvent) => {
    if (this.gameOver) return;
    if (event.key === 'ArrowLeft') {
      this.move(-1);
    } else if (event.key === 'ArrowRight') {
      this.move(1);
    } else if (event.key === 'ArrowDown') {
      this.moveDown();
    } else if (event.key === 'ArrowUp') {
      this.rotate();
    }
  };

  move(dir: number) {
    if (this.canPlace(this.currentTetromino, this.currentRow, this.currentCol + dir)) {
      this.currentCol += dir;
      this.drawBoard();
    }
  }

  rotate() {
    const rotated = this.currentTetromino[0].map((_, i) => this.currentTetromino.map(row => row[i]).reverse());
    if (this.canPlace(rotated, this.currentRow, this.currentCol)) {
      this.currentTetromino = rotated;
      this.drawBoard();
    }
  }

  spawnTetromino() {
    this.currentTetromino = this.nextTetromino.map(row => [...row]);
    this.currentTetrominoIndex = this.nextTetrominoIndex;
    this.currentRow = 0;
    this.currentCol = 3;
    this.prepareNextTetromino();
    if (!this.canPlace(this.currentTetromino, this.currentRow, this.currentCol)) {
      // Game over logic
      if (this.intervalId) clearInterval(this.intervalId);
      this.gameOver = true;
    }
    this.drawBoard();
  }

  moveDown() {
    if (this.canPlace(this.currentTetromino, this.currentRow + 1, this.currentCol)) {
      this.currentRow++;
    } else {
      this.mergeTetromino();
      this.clearFullLines();
      this.spawnTetromino();
    }
  }

  canPlace(shape: number[][], row: number, col: number): boolean {
    for (let r = 0; r < shape.length; r++) {
      for (let c = 0; c < shape[r].length; c++) {
        if (shape[r][c]) {
          const boardRow = row + r;
          const boardCol = col + c;
          if (
            boardRow < 0 ||
            boardRow >= this.board.length ||
            boardCol < 0 ||
            boardCol >= this.board[0].length ||
            this.board[boardRow][boardCol]
          ) {
            return false;
          }
        }
      }
    }
    return true;
  }

  mergeTetromino() {
    for (let r = 0; r < this.currentTetromino.length; r++) {
      for (let c = 0; c < this.currentTetromino[r].length; c++) {
        if (this.currentTetromino[r][c]) {
          const boardRow = this.currentRow + r;
          const boardCol = this.currentCol + c;
          if (
            boardRow >= 0 &&
            boardRow < this.board.length &&
            boardCol >= 0 &&
            boardCol < this.board[0].length
          ) {
            this.board[boardRow][boardCol] = this.currentTetrominoIndex;
          }
        }
      }
    }
  }

  clearFullLines() {
    let newBoard = this.board.filter(row => row.some(cell => cell === 0));
    const linesCleared = this.board.length - newBoard.length;
    while (newBoard.length < this.board.length) {
      newBoard.unshift(Array(this.board[0].length).fill(0));
    }
    this.board = newBoard;
    if (linesCleared > 0) {
      this.score += linesCleared * 100;
      // Increase speed every 5 lines
      if (this.score > 0 && this.score % 500 === 0 && this.fallInterval > 100) {
        this.fallInterval -= 50;
        this.setFallInterval();
      }
      this.drawBoard();
    }
  }

  drawBoard() {
    // No-op: rendering is now handled in getCellClass
  }

  getCellClass(row: number, col: number): string {
    // If active tetromino covers this cell, show it
    for (let r = 0; r < this.currentTetromino.length; r++) {
      for (let c = 0; c < this.currentTetromino[r].length; c++) {
        if (this.currentTetromino[r][c]) {
          const boardRow = this.currentRow + r;
          const boardCol = this.currentCol + c;
          if (boardRow === row && boardCol === col) {
            return 'block-active ' + this.colorMap[this.currentTetrominoIndex];
          }
        }
      }
    }
    // Otherwise, show landed block
    const val = this.board[row][col];
    return this.colorMap[val] || '';
  }

  restart() {
    this.board = Array.from({ length: 20 }, () => Array(10).fill(0));
    this.score = 0;
    this.gameOver = false;
    this.fallInterval = 500;
    this.prepareNextTetromino();
    this.spawnTetromino();
    this.setFallInterval();
  }

  setFallInterval() {
    if (this.intervalId) clearInterval(this.intervalId);
    this.intervalId = setInterval(() => {
      this.moveDown();
    }, this.fallInterval);
  }

  prepareNextTetromino() {
    const idx = Math.floor(Math.random() * this.tetrominoes.length);
    this.nextTetrominoIndex = idx + 1;
    this.nextTetromino = this.tetrominoes[idx].map(row => [...row]);
  }
}

