import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', title: 'Home', loadComponent: () => import('./pages/home.page').then(m => m.HomePage) },
  { path: 'dogs', title: 'Dogs', loadComponent: () => import('./pages/dogs.page').then(m => m.DogsPage) },
  { path: 'cats', title: 'Cats', loadComponent: () => import('./pages/cats.page').then(m => m.CatsPage) },
  { path: 'fishes', title: 'Fishes', loadComponent: () => import('./pages/fishes.page').then(m => m.FishesPage) },
  { path: 'birds', title: 'Birds', loadComponent: () => import('./pages/birds.page').then(m => m.BirdsPage) },
  { path: 'address', title: 'Address', loadComponent: () => import('./pages/address.page').then(m => m.AddressPage) },
  { path: 'contact', title: 'Contact', loadComponent: () => import('./pages/contact.page').then(m => m.ContactPage) },
  { path: 'orders', title: 'Orders', loadComponent: () => import('./pages/orders.page').then(m => m.OrdersPage) },
  { path: 'admin', title: 'Admin', loadComponent: () => import('./pages/admin.page').then(m => m.AdminPage) },
  { path: 'pet/:id', title: 'Pet Details', loadComponent: () => import('./pages/pet-detail.page').then(m => m.PetDetailPage) },
  { path: '**', title: 'Not Found', loadComponent: () => import('./pages/not-found.page').then(m => m.NotFoundPage) },
];
