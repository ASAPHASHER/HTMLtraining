import { Component } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-address-page',
  standalone: true,
  imports: [MatFormFieldModule, MatInputModule, MatButtonModule, FormsModule],
  templateUrl: './address.page.html',
  styleUrls: ['./address.page.css']
})
export class AddressPage {
  address = { name: '', address: '', city: '', state: '', zip: '', phone: '' };

  saveAddress() {
    alert('Address saved! (Demo)');
  }
}
