import { Component } from '@angular/core';

@Component({
  selector: 'app-not-found.page',
  imports: [],
  templateUrl: './not-found.page.html',
  styleUrl: './not-found.page.css'
})
export class NotFoundPage {

}
