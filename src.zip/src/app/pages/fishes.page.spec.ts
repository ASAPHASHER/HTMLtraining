import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FishesPage } from './fishes.page';

describe('FishesPage', () => {
  let component: FishesPage;
  let fixture: ComponentFixture<FishesPage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FishesPage]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FishesPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
