import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatGridTile } from '@angular/material/grid-list';
import { NgFor } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-dogs-page',
  standalone: true,
  imports: [MatButtonModule, MatGridListModule, MatGridTile, NgFor, RouterLink],
  templateUrl: './dogs.page.html',
  styleUrls: ['./dogs.page.css']
})
export class DogsPage {
  dogs = [
    { id: 1, name: 'Buddy', age: 2, weight: 18, img: 'https://images.pexels.com/photos/4587997/pexels-photo-4587997.jpeg?auto=compress&w=400' },
    { id: 5, name: 'Charlie', age: 4, weight: 22, img: 'https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&w=400' },
    { id: 6, name: 'Rocky', age: 3, weight: 20, img: 'https://images.pexels.com/photos/1805164/pexels-photo-1805164.jpeg?auto=compress&w=400' },
    { id: 7, name: 'Max', age: 1, weight: 12, img: 'https://images.pexels.com/photos/1805164/pexels-photo-1805164.jpeg?auto=compress&w=400' },
    { id: 8, name: 'Bella', age: 3, weight: 15, img: 'https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&w=400' },
  ];
}
