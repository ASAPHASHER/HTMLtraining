import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatDialog } from '@angular/material/dialog';
import { Component, inject } from '@angular/core';
import { PetDialog } from './pet-dialog';

@Component({
  selector: 'app-admin-page',
  standalone: true,
  imports: [MatButtonModule, MatTableModule, MatIconModule],
  templateUrl: './admin.page.html',
  styleUrls: ['./admin.page.css']
})
export class AdminPage {
  pets = [
    { name: 'Buddy', species: 'Dog', age: 2, weight: 18, height: 45, photo: 'https://images.pexels.com/photos/4587997/pexels-photo-4587997.jpeg?auto=compress&w=400' },
    { name: 'Luna', species: 'Cat', age: 1, weight: 4, height: 25, photo: 'https://images.pexels.com/photos/45201/kitty-cat-kitten-pet-45201.jpeg?auto=compress&w=400' },
    { name: 'Goldfish', species: 'Fish', age: 0.5, weight: 0.05, height: 5, photo: 'https://images.pexels.com/photos/128756/pexels-photo-128756.jpeg?auto=compress&w=400' },
    { name: 'Parrot', species: 'Bird', age: 2, weight: 0.4, height: 30, photo: 'https://images.pexels.com/photos/45911/peacock-bird-plumage-color-45911.jpeg?auto=compress&w=400' },
  ];
  displayedColumns = ['photo', 'name', 'species', 'age', 'weight', 'height', 'actions'];

  dialog = inject(MatDialog);

  openAddPetDialog() {
    this.dialog.open(PetDialog, {
      data: {}
    }).afterClosed().subscribe(result => {
      if (result) {
        this.pets = [...this.pets, result];
      }
    });
  }
  editPet(pet: any) {
    this.dialog.open(PetDialog, {
      data: { pet }
    }).afterClosed().subscribe(result => {
      if (result) {
        this.pets = this.pets.map(p => p === pet ? result : p);
      }
    });
  }
  deletePet(pet: any) {
    // TODO: Remove pet from list
    this.pets = this.pets.filter(p => p !== pet);
  }
}
