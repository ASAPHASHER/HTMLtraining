import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatGridTile } from '@angular/material/grid-list';
import { NgFor } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-birds-page',
  standalone: true,
  imports: [MatButtonModule, MatGridListModule, MatGridTile, NgFor, RouterLink],
  templateUrl: './birds.page.html',
  styleUrls: ['./birds.page.css']
})
export class BirdsPage {
  birds = [
    { id: 4, name: 'Parrot', age: 2, weight: 400, img: 'https://images.pexels.com/photos/45911/peacock-bird-plumage-color-45911.jpeg?auto=compress&w=400' },
    { id: 17, name: 'Canary', age: 1, weight: 30, img: 'https://images.pexels.com/photos/45911/peacock-bird-plumage-color-45911.jpeg?auto=compress&w=400' },
    { id: 18, name: 'Peacock', age: 4, weight: 5000, img: 'https://images.pexels.com/photos/45911/peacock-bird-plumage-color-45911.jpeg?auto=compress&w=400' },
    { id: 19, name: 'Sparrow', age: 2, weight: 25, img: 'https://images.pexels.com/photos/45911/peacock-bird-plumage-color-45911.jpeg?auto=compress&w=400' },
    { id: 20, name: 'Finch', age: 3, weight: 20, img: 'https://images.pexels.com/photos/45911/peacock-bird-plumage-color-45911.jpeg?auto=compress&w=400' },
  ];
}
