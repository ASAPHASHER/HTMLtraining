import { Component, Inject, inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-pet-dialog',
  standalone: true,
  imports: [MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, FormsModule],
  templateUrl: './pet-dialog.html',
  styleUrls: ['./pet-dialog.css']
})
export class PetDialog {
  dialogRef = inject(MatDialogRef<PetDialog>);
  data = inject(MAT_DIALOG_DATA);
  pet: any = {};

  constructor() {
    if (this.data?.pet) {
      this.pet = { ...this.data.pet };
    }
  }

  save() {
    this.dialogRef.close(this.pet);
  }

  close() {
    this.dialogRef.close();
  }
}
