import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatGridTile } from '@angular/material/grid-list';
import { NgFor } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-home-page',
  standalone: true,
  imports: [MatButtonModule, MatGridListModule, MatGridTile, NgFor, RouterLink],
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.css']
})
export class HomePage {
  categories = [
    { name: 'Dogs', link: '/dogs', img: 'https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&w=400' },
    { name: 'Cats', link: '/cats', img: 'https://images.pexels.com/photos/45201/kitty-cat-kitten-pet-45201.jpeg?auto=compress&w=400' },
    { name: 'Fishes', link: '/fishes', img: 'https://images.pexels.com/photos/128756/pexels-photo-128756.jpeg?auto=compress&w=400' },
    { name: 'Birds', link: '/birds', img: 'https://images.pexels.com/photos/45911/peacock-bird-plumage-color-45911.jpeg?auto=compress&w=400' },
  ];
}
