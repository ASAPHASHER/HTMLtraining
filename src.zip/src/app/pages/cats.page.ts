import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatGridTile } from '@angular/material/grid-list';
import { NgFor } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-cats-page',
  standalone: true,
  imports: [MatButtonModule, MatGridListModule, MatGridTile, NgFor, RouterLink],
  templateUrl: './cats.page.html',
  styleUrls: ['./cats.page.css']
})
export class CatsPage {
  cats = [
    { id: 2, name: 'Luna', age: 1, weight: 4, img: 'https://images.pexels.com/photos/45201/kitty-cat-kitten-pet-45201.jpeg?auto=compress&w=400' },
    { id: 9, name: 'Simba', age: 2, weight: 5, img: 'https://images.pexels.com/photos/320014/pexels-photo-320014.jpeg?auto=compress&w=400' },
    { id: 10, name: 'Milo', age: 3, weight: 6, img: 'https://images.pexels.com/photos/416160/pexels-photo-416160.jpeg?auto=compress&w=400' },
    { id: 11, name: 'Oliver', age: 2, weight: 5, img: 'https://images.pexels.com/photos/45201/kitty-cat-kitten-pet-45201.jpeg?auto=compress&w=400' },
    { id: 12, name: 'Chloe', age: 4, weight: 7, img: 'https://images.pexels.com/photos/320014/pexels-photo-320014.jpeg?auto=compress&w=400' },
  ];
}
