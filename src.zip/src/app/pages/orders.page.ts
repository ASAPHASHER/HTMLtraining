import { Component, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { NgFor, NgIf, DatePipe } from '@angular/common';

// Simple in-memory cart for demo
const CART: any[] = [];
const ORDERS: any[] = [];

@Component({
  selector: 'app-orders-page',
  standalone: true,
  imports: [MatButtonModule, NgFor, NgIf, DatePipe],
  templateUrl: './orders.page.html',
  styleUrls: ['./orders.page.css']
})
export class OrdersPage {
  cart = CART;
  orders = ORDERS;

  removeFromCart(item: any) {
    const idx = this.cart.indexOf(item);
    if (idx > -1) this.cart.splice(idx, 1);
  }

  checkout() {
    if (this.cart.length === 0) return;
    this.orders.push({
      date: new Date(),
      items: [...this.cart]
    });
    alert('Order placed!');
    this.cart.length = 0;
  }
}
