import { Component, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { NgIf } from '@angular/common';
import { OrdersPage } from './orders.page';

// For demo, use static data. In a real app, use a shared service.
const PETS = [
  { id: 1, name: 'Buddy', species: 'Dog', age: 2, weight: 18, height: 45, photo: 'https://images.pexels.com/photos/4587997/pexels-photo-4587997.jpeg?auto=compress&w=400', description: 'Friendly and playful dog.' },
  { id: 2, name: 'Luna', species: 'Cat', age: 1, weight: 4, height: 25, photo: 'https://images.pexels.com/photos/45201/kitty-cat-kitten-pet-45201.jpeg?auto=compress&w=400', description: 'Cute and cuddly cat.' },
  { id: 3, name: 'Goldfish', species: 'Fish', age: 0.5, weight: 0.05, height: 5, photo: 'https://images.pexels.com/photos/128756/pexels-photo-128756.jpeg?auto=compress&w=400', description: 'Colorful goldfish.' },
  { id: 4, name: 'Parrot', species: 'Bird', age: 2, weight: 0.4, height: 30, photo: 'https://images.pexels.com/photos/45911/peacock-bird-plumage-color-45911.jpeg?auto=compress&w=400', description: 'Talkative parrot.' },
];

@Component({
  selector: 'app-pet-detail-page',
  standalone: true,
  imports: [MatButtonModule, NgIf],
  templateUrl: './pet-detail.page.html',
  styleUrls: ['./pet-detail.page.css']
})
export class PetDetailPage {
  route = inject(ActivatedRoute);
  router = inject(Router);
  pet: any = null;

  constructor() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.pet = PETS.find(p => p.id === id);
  }

  addToCart() {
    OrdersPage.prototype.cart.push(this.pet);
    alert('Added to cart!');
    this.router.navigate(['/orders']);
  }
}
