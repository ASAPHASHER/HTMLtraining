import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatGridTile } from '@angular/material/grid-list';
import { NgFor } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-fishes-page',
  standalone: true,
  imports: [MatButtonModule, MatGridListModule, MatGridTile, NgFor, RouterLink],
  templateUrl: './fishes.page.html',
  styleUrls: ['./fishes.page.css']
})
export class FishesPage {
  fishes = [
    { id: 3, name: 'Goldfish', age: 6, weight: 50, img: 'https://images.pexels.com/photos/128756/pexels-photo-128756.jpeg?auto=compress&w=400' },
    { id: 13, name: 'Betta', age: 4, weight: 30, img: 'https://images.pexels.com/photos/128756/pexels-photo-128756.jpeg?auto=compress&w=400' },
    { id: 14, name: 'Guppy', age: 3, weight: 10, img: 'https://images.pexels.com/photos/161931/fish-tank-betta-fish-fish-bowl-161931.jpeg?auto=compress&w=400' },
    { id: 15, name: 'Molly', age: 2, weight: 15, img: 'https://images.pexels.com/photos/128756/pexels-photo-128756.jpeg?auto=compress&w=400' },
    { id: 16, name: 'Tetra', age: 1, weight: 8, img: 'https://images.pexels.com/photos/161931/fish-tank-betta-fish-fish-bowl-161931.jpeg?auto=compress&w=400' },
  ];
}
